fun main()=try{
    var color1=Colors.Blue
    var weekday1=Weekday.Saturday

    println(color1.colorName())
    println(color1.belongRainbow())
    println(color1.hex())
    println(color1.rgb())

    println(weekday1.weekdayName())
    println(weekday1.num())
    println(weekday1.weekend())
    println(weekday1.odd_or_even())

}
catch (e:NumberFormatException){println("error")}