enum class Weekday {
    Monday{
        override fun weekdayName() ="понедельник"
        override fun num()=1
        override fun odd_or_even()="odd"
        override fun weekend()=false
          },
    Tuesday{
        override fun weekdayName() = "вторник"
        override fun num()=2
        override fun odd_or_even()="even"
    override fun weekend()=false
           },
    Wednesday{
        override fun weekdayName() ="среда"
        override fun num()=3
        override fun odd_or_even()="odd"
    override fun weekend()=false
             },
    Thursday{
        override fun weekdayName() ="четверг"
        override fun num()=4
        override fun odd_or_even()="even"
    override fun weekend()=false
            },
    Friday{
        override fun weekdayName()="пятница"
        override fun num()=5
        override fun odd_or_even()="odd"
    override fun weekend()=false
          },
    Saturday{
        override fun weekdayName() ="суббота"
        override fun num()=6
        override fun odd_or_even()="even"
    override fun weekend()=true
    },
    Sunday{
        override fun weekdayName() ="воскресение"
        override fun num()=7
        override fun odd_or_even()="odd"
    override fun weekend()=true
    };
    abstract fun num():Int
    abstract fun weekdayName(): String
    abstract fun odd_or_even(): String
    abstract fun weekend(): Boolean

}