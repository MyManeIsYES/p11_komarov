enum class Colors {

    Red {
        override fun colorName() = "Красный"
        override fun hex() = "0xFF0000"
        override fun belongRainbow()=true
        override fun rgb() = "(255, 0, 0)"
    },
    Blue {
        override fun colorName() = "Голубой"
        override fun hex() = "0x0000FF"
        override fun belongRainbow()=true
        override fun rgb() = "(0, 0, 255)"
    },
    Green {
        override fun colorName() = "Зелёный"
        override fun hex() = "0x00FF00"
        override fun belongRainbow()=true
        override fun rgb() = "(0, 255, 0)"
    },
    Raspberry{
        override fun colorName() = "Малиновый"
        override fun hex() = "0xe30b5c"
        override fun belongRainbow()=false
        override fun rgb() = "(227, 11, 92)"
    },
    Yellow{
        override fun colorName() = "Желтый"
        override fun hex() = "0xffff00"
        override fun belongRainbow()=true
        override fun rgb() = "(255, 255, 0)"
    };

    abstract fun rgb(): String
    abstract fun colorName(): String
    abstract fun belongRainbow(): Boolean
    abstract fun hex(): String

}